def strcat(a, b):
    if type(a) != type("") or type(b) != type(""):
        return None
    return a + b
