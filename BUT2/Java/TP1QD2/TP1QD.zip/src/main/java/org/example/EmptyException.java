package org.example;

public class EmptyException extends Exception {
	public EmptyException() {
          super("La liste est vide");
	}
}
