public class AppartementDouche extends Appartement implements Douche {
    public AppartementDouche() {
        super();
    }
}
