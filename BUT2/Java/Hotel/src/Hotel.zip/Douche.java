public interface Douche {
}
