public class ChambreDouble extends Chambre {
    public ChambreDouble() {
        super(2);
    }

    @Override
    public String typeChambre() {
        return "Chambre double";
    }
}
