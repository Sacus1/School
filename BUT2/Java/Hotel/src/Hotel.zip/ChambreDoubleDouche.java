public class ChambreDoubleDouche extends ChambreDouble implements Douche {
    public ChambreDoubleDouche() {
        super();
    }
}
